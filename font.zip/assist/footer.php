<?php

echo '<div class="container-fluid bg-white pt-3 shadow-lg mt-4">
<div class="container">
<footer class="mt-4">
	<div class="row">
		<div class="col-md-4 mb-3">
			<p class="text-primary font-weight-bold">Pages</p>



			<p><a href="index.php" class="text-decoration-none text-primary">Home</a></p>
			<p><a href="about-us" class="text-decoration-none text-primary">About Us</a></p>
			<p><a href="privacy" class="text-decoration-none text-primary">Privacy Policy</a></p>
			<p><a href="terms" class="text-decoration-none text-primary">Terms</a></p>
		</div>
		<div class="col-md-4 mb-3">
			<p class="text-primary font-weight-bold">Social Links</p>
			<p><a href="#" class="text-decoration-none text-primary"><i class="fa fa-facebook"></i> Facebook</a></p>
			<p><a href="#" class="text-decoration-none text-primary"><i class="fa fa-youtube"></i> Youtube</a></p>
			<p><a href="#" class="text-decoration-none text-primary"><i class="fa fa-linkedin"></i> Linkedin</a></p>
			<p><a href="#" class="text-decoration-none text-primary"><i class="fa fa-telegram"></i> Telegram</a></p>
		</div>
		<div class="col-md-4">
			<p class="text-primary font-weight-bold">Developer Info</p>
			<p class="text-primary">This Website completely develop by <a href="https://unlockdream.com">unlockdream.com</a></p>
		</div>
	</div>
</footer>
</div>
</div>'


?>