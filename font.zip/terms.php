<!DOCTYPE html>
<html>
<head>
	<title>Terms</title>
	
	  <meta name="description" content="your nice">
	  <meta name="keywords" content="keyword, keyword2, keyword3">
	  <meta name="author" content="your name">
	   <?php  require_once("assist/cdn.php");?>
</head>
<body>
	<?php require_once("assist/header.php");?>
	
<div class="container">



	<!--Yo can write here-->
	<h1>Write Your hext here</h1>




</div>
<?php require_once("assist/footer.php");?>
</body>
</html>